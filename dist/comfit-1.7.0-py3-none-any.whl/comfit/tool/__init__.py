from .tool_colormaps import tool_colormap_bluewhitered, tool_colormap_angle, tool_colormap_sunburst
from .tool_animation import tool_save_plot_matplotlib, tool_save_plot, tool_make_animation_movie, tool_make_animation_gif
from .tool_export_plot_functions import tool_export_rotating_plot
from .tool_plot_manipulation_functions import tool_zoom_plot
from .tool_math_functions import tool_multinom

from .tool_set_plot_axis_properties_matplotlib import tool_set_plot_axis_properties_matplotlib
from .tool_set_plot_axis_properties_plotly import tool_set_plot_axis_properties_plotly

from .tool_complete_field import tool_complete_field

from .tool_add_spacing_2D import tool_add_spacing_2D
from .tool_add_spacing_3D import tool_add_spacing_3D

from .tool_make_subplots import tool_make_subplots

from .tool_print_in_color import tool_print_in_color
from .tool_configure_axis import tool_configure_axis