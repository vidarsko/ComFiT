
def tool_extract_plot_data(self):
    pass