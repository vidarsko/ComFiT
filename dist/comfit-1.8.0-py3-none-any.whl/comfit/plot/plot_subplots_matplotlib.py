
def plot_subplots_matplotlib(number_of_rows, number_of_columns, *args, **kwargs):
    print('plot_subplots_matplotlib, not implemented yet')
    pass