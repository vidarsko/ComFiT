import numpy as np
import scipy as sp

class BaseSystemConf:
    """ Configuration methods for the base system class"""
    pass